Author : Thusitha Nuwan
Date : 31-Oct-2012
email : tmnuwan12@yahoo.com

Thanks for using this utility.
Please feel free to modify code as you wish. 

This utility is written in Java. You can run this application in cosole or inside windows service.
I will extend that feature to Linux in near future. Please make sure you have JAVA_HOME enviroment
variable setup and PATH is pointing to it.

############################Installation############################

1)Extract httpUtil-intaller.zip file.
2)If you need to run the application in cosole, run ${httpUtil_HOME}/bin/httpUtil.bat
3)If you need to run the application as a windows service, urn ${httpUtil_HOME}/bin/InstallhttpUtil-NT.bat
4)Once you start the application there are log files written to three places
  a)Log file for actual application inside ${httpUtil_HOME}/bin/INTERNAL_LOGFILE_IS_UNDIFINED/
  b)A daily rolling log file for all ping requests in C:\{current_date}_transmission_log.csv. i.e.31-10-	2012_transmission_log
  C)Java service wrapper log in ${httpUtil_HOME}/log/

############################Known bugs############################

1)Location of internal log file is current written to ${httpUtil_HOME}/bin/INTERNAL_LOGFILE_IS_UNDIFINED/
  The reason for this is few missing config parameters in the settings file. I will fix this one soon.

If you find any new bugs or any improvement please let me know.
